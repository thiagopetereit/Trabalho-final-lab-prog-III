#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "carcontroller.h"
#include <QCloseEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , carController(new CarController(this))
{
    ui->setupUi(this);

    connect(ui->actionConfigureSerial, &QAction::triggered, this, &MainWindow::openSerialConfigDialog);

    connect(carController, &CarController::ultrasonicDistanceChanged, this, &MainWindow::updateUltrasonicDistance);

    connect(ui->forwardButton, &QPushButton::pressed, this, &MainWindow::on_forwardButton_pressed);
    connect(ui->forwardButton, &QPushButton::released, this, &MainWindow::on_forwardButton_released);

    connect(ui->backButton, &QPushButton::pressed, this, &MainWindow::on_backButton_pressed);
    connect(ui->backButton, &QPushButton::released, this, &MainWindow::on_backButton_released);

    connect(ui->leftButton, &QPushButton::pressed, this, &MainWindow::on_leftButton_pressed);
    connect(ui->leftButton, &QPushButton::released, this, &MainWindow::on_leftButton_released);

    connect(ui->rightButton, &QPushButton::pressed, this, &MainWindow::on_rightButton_pressed);
    connect(ui->rightButton, &QPushButton::released, this, &MainWindow::on_rightButton_released);
}

MainWindow::~MainWindow()
{
    delete ui;
    delete carController;
}

void MainWindow::openSerialConfigDialog()
{
    SerialConfigDialog dialog(this);
    if (dialog.exec() == QDialog::Accepted) {
        QString selectedPort = dialog.getSelectedPortName();
        if (!selectedPort.isEmpty()) {
            carController->connectToPort(selectedPort);
            statusBar()->showMessage("Conectado à porta: " + selectedPort, 5000);
        } else {
            statusBar()->showMessage("Nenhuma porta selecionada.", 5000);
        }
    }
}

void MainWindow::updateUltrasonicDistance(int distance)
{
    // Atualiza a statusBar com a distância do sensor ultrassônico
    statusBar()->showMessage(QString("Distância do objeto: %1 cm").arg(distance));
}

void MainWindow::on_distHorizontalSlider_sliderMoved(int value)
{
    int distance = 5 + (value - 1) * 5; // Mapeia de 1-10 para 5-50
    carController->setDistance(distance);
    statusBar()->showMessage(QString("Distância configurada para: %1 cm").arg(distance));
}

void MainWindow::on_autoButton_clicked() {
    static bool isAutoEnabled = false;
    isAutoEnabled = !isAutoEnabled;
    carController->toggleAutoMode(isAutoEnabled);
    ui->autoButton->setText(isAutoEnabled ? "Desativar Estacionamento Automático" : "Ativar Estacionamento Automático");
    statusBar()->showMessage(isAutoEnabled ? "Modo automático ativado" : "Modo automático desativado", 3000);
}

void MainWindow::on_forwardButton_pressed()
{
    carController->moveForward();
    qDebug() << "Botão FORWARD pressionado";
}

void MainWindow::on_forwardButton_released()
{
    carController->stopMotors();
    qDebug() << "Botão FORWARD liberado";
}

void MainWindow::on_backButton_pressed()
{
    carController->moveBack();
    qDebug() << "Botão BACK pressionado";
}

void MainWindow::on_backButton_released()
{
    carController->stopMotors();
    qDebug() << "Botão BACK liberado";
}

void MainWindow::on_leftButton_pressed()
{
    carController->sendCommand("CMD:LEFT");
    qDebug() << "Botão LEFT pressionado";
}

void MainWindow::on_leftButton_released()
{
    carController->sendCommand("CMD:STOP");
    qDebug() << "Botão LEFT liberado";
}

void MainWindow::on_rightButton_pressed()
{
    carController->sendCommand("CMD:RIGHT");
    qDebug() << "Botão RIGHT pressionado";
}

void MainWindow::on_rightButton_released()
{
    carController->sendCommand("CMD:STOP");
    qDebug() << "Botão RIGHT liberado";
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    // Garantir que o carro pare
    if (carController->isConnected()) { // Verifica se há uma conexão ativa
        carController->sendCommand("CMD:STOP"); // Envia o comando de parada
        qDebug() << "Comando CMD:STOP enviado antes de fechar a aplicação.";
    }

    // Desativar o modo automático
    carController->toggleAutoMode(false); // Desativa o modo automático
    qDebug() << "Modo automático desativado.";

    // Atualizar o estado do botão autoButton
    ui->autoButton->setText("Ativar Estacionamento Automático");
    qDebug() << "Botão autoButton atualizado para OFF.";

    // Aceita o fechamento da janela
    event->accept();
}
