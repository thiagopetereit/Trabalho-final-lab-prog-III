    #include "serialconfigdialog.h"
#include "ui_serialconfigdialog.h"
#include <QMessageBox>

SerialConfigDialog::SerialConfigDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SerialConfigDialog)
{
    ui->setupUi(this);

    // Populate available serial ports
    const auto ports = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &port : ports) {
        ui->portComboBox->addItem(port.portName());
    }
}

SerialConfigDialog::~SerialConfigDialog()
{
    delete ui;
}

QString SerialConfigDialog::getSelectedPortName() const
{
    return selectedPortName;
}

void SerialConfigDialog::on_connectButton_clicked()
{
    if (ui->portComboBox->currentIndex() == -1) {
        QMessageBox::warning(this, "Connection Error", "Please select a valid port.");
        return;
    }

    selectedPortName = ui->portComboBox->currentText();
    accept(); // Close the dialog and signal success
}
