#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "carcontroller.h"
#include "serialconfigdialog.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void openSerialConfigDialog();
    void updateUltrasonicDistance(int distance);
    void on_distHorizontalSlider_sliderMoved(int position);

    void on_forwardButton_pressed();
    void on_forwardButton_released();
    void on_backButton_pressed();
    void on_backButton_released();
    void on_leftButton_pressed();
    void on_leftButton_released();
    void on_rightButton_pressed();
    void on_rightButton_released();

    void on_autoButton_clicked();

    void closeEvent(QCloseEvent *event) override;

private:
    Ui::MainWindow *ui;
    CarController *carController;
};

#endif // MAINWINDOW_H
