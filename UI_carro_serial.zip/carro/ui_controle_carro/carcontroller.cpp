#include "carcontroller.h"
#include <QThread>
#include <QDebug>

// Construtor inicializa a referência para SerialHandler
CarController::CarController(QObject *parent) : QObject(parent), serial(new QSerialPort(this))
{
}

CarController::~CarController()
{
    if (serial->isOpen()) {
        serial->close();
    }
    delete serial;
}

void CarController::connectToPort(const QString &portName)
{
    serial->setPortName(portName);
    if (!serial->open(QIODevice::ReadWrite)) {
        qDebug() << "Failed to open port" << portName;
    } else {
        qDebug() << "Connected to port" << portName;
    }
}

void CarController::readUltrasonicSensor()
{
    // Simula a leitura da distância
    int distance = 25; // Exemplo de leitura
    emit ultrasonicDistanceChanged(distance);
}

bool CarController::isConnected() const
{
    return serial && serial->isOpen(); // Verifica se o objeto serial existe e se a porta está aberta
}


void CarController::sendCommand(const QString &command)
{
    if (serial->isOpen() && serial->isWritable()) {
        QString commandWithNewline = command + "\n"; // Adiciona quebra de linha
        qint64 bytesWritten = serial->write(commandWithNewline.toUtf8());
        if (bytesWritten == -1) {
            qDebug() << "Erro ao enviar comando:" << commandWithNewline << "- Erro:" << serial->errorString();
        } else {
            qDebug() << "Comando enviado com sucesso:" << commandWithNewline << "- Bytes escritos:" << bytesWritten;
        }
    } else {
        qDebug() << "Erro: Porta serial não está aberta ou não é gravável. Comando:" << command;
    }
}

void CarController::setDistance(int distance)
{
    QString command = QString("DIST:%1").arg(distance);
    sendCommand(command);
}

void CarController::moveForward()
{
    sendCommand("CMD:FORWARD");
}

void CarController::moveBack()
{
    sendCommand("CMD:BACK");
}

void CarController::turnLeft()
{
    sendCommand("CMD:LEFT");
}

void CarController::turnRight()
{
    sendCommand("CMD:RIGHT");
}

void CarController::stopMotors()
{
    sendCommand("CMD:STOP");
}

// Alternar o modo de estacionamento automático
void CarController::toggleAutoMode(bool enable)
{
    sendCommand(enable ? "AUTO:ON" : "AUTO:OFF");
}
