#ifndef CARCONTROLLER_H
#define CARCONTROLLER_H

#include <QObject>
#include <QSerialPort>

class CarController : public QObject
{
    Q_OBJECT

public:
    explicit CarController(QObject *parent = nullptr);
    ~CarController();

    bool isConnected() const;

    void connectToPort(const QString &portName);
    void sendCommand(const QString &command);

    void setDistance(int distance);
    void moveForward();
    void moveBack();
    void turnLeft();
    void turnRight();
    void stopMotors();
    void toggleAutoMode(bool enable);
    void readUltrasonicSensor();

signals:
    void ultrasonicDistanceChanged(int distance);

private:
    QSerialPort *serial;
};

#endif // CARCONTROLLER_H
