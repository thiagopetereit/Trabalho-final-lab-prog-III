/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_3;
    QGridLayout *gridLayout;
    QPushButton *direitaPushButton;
    QPushButton *frentePushButton;
    QPushButton *esquerdaPushButton;
    QPushButton *trasPushButton;
    QLabel *label;
    QGridLayout *gridLayout_2;
    QLabel *label05;
    QLabel *label25;
    QLabel *label50;
    QLabel *label20;
    QLabel *label15;
    QLabel *label10;
    QLabel *label45;
    QLabel *label35;
    QLabel *label40;
    QLabel *label30;
    QSlider *distHorizontalSlider;
    QMenuBar *menubar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(548, 309);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_3 = new QGridLayout(centralwidget);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(-1, -1, 60, -1);
        direitaPushButton = new QPushButton(centralwidget);
        direitaPushButton->setObjectName(QString::fromUtf8("direitaPushButton"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(50);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(direitaPushButton->sizePolicy().hasHeightForWidth());
        direitaPushButton->setSizePolicy(sizePolicy);

        gridLayout->addWidget(direitaPushButton, 1, 2, 1, 1);

        frentePushButton = new QPushButton(centralwidget);
        frentePushButton->setObjectName(QString::fromUtf8("frentePushButton"));

        gridLayout->addWidget(frentePushButton, 0, 1, 1, 1);

        esquerdaPushButton = new QPushButton(centralwidget);
        esquerdaPushButton->setObjectName(QString::fromUtf8("esquerdaPushButton"));

        gridLayout->addWidget(esquerdaPushButton, 1, 0, 1, 1);

        trasPushButton = new QPushButton(centralwidget);
        trasPushButton->setObjectName(QString::fromUtf8("trasPushButton"));

        gridLayout->addWidget(trasPushButton, 2, 1, 1, 1);

        gridLayout->setColumnStretch(0, 30);

        gridLayout_3->addLayout(gridLayout, 1, 0, 1, 1);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);
        label->setMinimumSize(QSize(0, 0));
        QFont font;
        font.setPointSize(26);
        font.setBold(true);
        label->setFont(font);
        label->setText(QString::fromUtf8("30"));
        label->setTextFormat(Qt::AutoText);
        label->setScaledContents(false);
        label->setAlignment(Qt::AlignCenter);
        label->setMargin(150);

        gridLayout_3->addWidget(label, 1, 1, 1, 1);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setHorizontalSpacing(6);
        gridLayout_2->setVerticalSpacing(0);
        gridLayout_2->setContentsMargins(-1, 0, -1, 20);
        label05 = new QLabel(centralwidget);
        label05->setObjectName(QString::fromUtf8("label05"));
        label05->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gridLayout_2->addWidget(label05, 1, 0, 1, 1);

        label25 = new QLabel(centralwidget);
        label25->setObjectName(QString::fromUtf8("label25"));
        label25->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gridLayout_2->addWidget(label25, 1, 4, 1, 1);

        label50 = new QLabel(centralwidget);
        label50->setObjectName(QString::fromUtf8("label50"));
        label50->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gridLayout_2->addWidget(label50, 1, 9, 1, 1);

        label20 = new QLabel(centralwidget);
        label20->setObjectName(QString::fromUtf8("label20"));
        label20->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gridLayout_2->addWidget(label20, 1, 3, 1, 1);

        label15 = new QLabel(centralwidget);
        label15->setObjectName(QString::fromUtf8("label15"));
        label15->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gridLayout_2->addWidget(label15, 1, 2, 1, 1);

        label10 = new QLabel(centralwidget);
        label10->setObjectName(QString::fromUtf8("label10"));
        label10->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gridLayout_2->addWidget(label10, 1, 1, 1, 1);

        label45 = new QLabel(centralwidget);
        label45->setObjectName(QString::fromUtf8("label45"));
        label45->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gridLayout_2->addWidget(label45, 1, 8, 1, 1);

        label35 = new QLabel(centralwidget);
        label35->setObjectName(QString::fromUtf8("label35"));
        label35->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gridLayout_2->addWidget(label35, 1, 6, 1, 1);

        label40 = new QLabel(centralwidget);
        label40->setObjectName(QString::fromUtf8("label40"));
        label40->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gridLayout_2->addWidget(label40, 1, 7, 1, 1);

        label30 = new QLabel(centralwidget);
        label30->setObjectName(QString::fromUtf8("label30"));
        label30->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gridLayout_2->addWidget(label30, 1, 5, 1, 1);

        distHorizontalSlider = new QSlider(centralwidget);
        distHorizontalSlider->setObjectName(QString::fromUtf8("distHorizontalSlider"));
        distHorizontalSlider->setMinimum(5);
        distHorizontalSlider->setMaximum(50);
        distHorizontalSlider->setPageStep(5);
        distHorizontalSlider->setOrientation(Qt::Horizontal);
        distHorizontalSlider->setTickPosition(QSlider::TicksAbove);
        distHorizontalSlider->setTickInterval(5);

        gridLayout_2->addWidget(distHorizontalSlider, 2, 0, 1, 10);


        gridLayout_3->addLayout(gridLayout_2, 0, 0, 1, 2);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 548, 22));
        MainWindow->setMenuBar(menubar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        direitaPushButton->setText(QCoreApplication::translate("MainWindow", "\342\206\222", nullptr));
        frentePushButton->setText(QCoreApplication::translate("MainWindow", "\342\206\221", nullptr));
        esquerdaPushButton->setText(QCoreApplication::translate("MainWindow", "\342\206\220", nullptr));
        trasPushButton->setText(QCoreApplication::translate("MainWindow", "\342\206\223", nullptr));
        label05->setText(QCoreApplication::translate("MainWindow", "5 cm", nullptr));
        label25->setText(QCoreApplication::translate("MainWindow", "25 cm", nullptr));
        label50->setText(QCoreApplication::translate("MainWindow", "50 cm", nullptr));
        label20->setText(QCoreApplication::translate("MainWindow", "20 cm", nullptr));
        label15->setText(QCoreApplication::translate("MainWindow", "15 cm", nullptr));
        label10->setText(QCoreApplication::translate("MainWindow", "10 cm", nullptr));
        label45->setText(QCoreApplication::translate("MainWindow", "45 cm", nullptr));
        label35->setText(QCoreApplication::translate("MainWindow", "35 cm", nullptr));
        label40->setText(QCoreApplication::translate("MainWindow", "40 cm", nullptr));
        label30->setText(QCoreApplication::translate("MainWindow", "30 cm", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
