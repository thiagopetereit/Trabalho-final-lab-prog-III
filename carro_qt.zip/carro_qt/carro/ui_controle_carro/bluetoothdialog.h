#ifndef BLUETOOTHDIALOG_H
#define BLUETOOTHDIALOG_H

#include <QDialog>  // a classe QDialog é a base para o BluetoothDialog
#include <QBluetoothDeviceDiscoveryAgent>
#include <QBluetoothSocket>
#include <QListWidgetItem>

namespace Ui {
class BluetoothDialog;
}

class BluetoothDialog : public QDialog
{
    Q_OBJECT

public:
    explicit BluetoothDialog(QWidget *parent = nullptr);
    ~BluetoothDialog();

signals:

    void bluetoothConnected(QBluetoothSocket *socket);  // Sinal que será emitido quando o Bluetooth conectar

private slots:
    void on_searchPushButton_clicked();
    void deviceDiscovered(const QBluetoothDeviceInfo &info);
    void on_connectPushButton_clicked();
    void socketConnected();
    void socketErrorOccurred(QBluetoothSocket::SocketError error);

private:
    Ui::BluetoothDialog *ui;
    QBluetoothDeviceDiscoveryAgent *discoveryAgent;
    QBluetoothSocket *bluetoothSocket;
};

#endif // BLUETOOTHDIALOG_H
