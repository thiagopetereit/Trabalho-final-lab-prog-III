#include "bluetoothdialog.h"
#include "ui_bluetoothdialog.h"
#include <QBluetoothLocalDevice>
#include <QDebug>

BluetoothDialog::BluetoothDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::BluetoothDialog),
    discoveryAgent(new QBluetoothDeviceDiscoveryAgent(this)),
    bluetoothSocket(new QBluetoothSocket(QBluetoothServiceInfo::RfcommProtocol, this))
{
    ui->setupUi(this);

    // Conectar sinais aos slots
    connect(discoveryAgent, &QBluetoothDeviceDiscoveryAgent::deviceDiscovered,
        this, &BluetoothDialog::deviceDiscovered);
    connect(bluetoothSocket, &QBluetoothSocket::connected,
        this, &BluetoothDialog::socketConnected);
    connect(bluetoothSocket, QOverload<QBluetoothSocket::SocketError>::of(&QBluetoothSocket::errorOccurred),
        this, &BluetoothDialog::socketErrorOccurred);

    // Conectar ao sinal que indica mudança de estado do socket (para depuração)
    connect(bluetoothSocket, &QBluetoothSocket::stateChanged, this, [](QBluetoothSocket::SocketState state) {
        qDebug() << "Estado do socket Bluetooth mudou para:" << state;
    });
}

BluetoothDialog::~BluetoothDialog()
{
    delete ui;
}

void BluetoothDialog::on_searchPushButton_clicked()
{
    ui->listWidget->clear();
    discoveryAgent->start();
}

void BluetoothDialog::deviceDiscovered(const QBluetoothDeviceInfo &info)
{
    QString deviceLabel = QString("%1 (%2)").arg(info.name()).arg(info.address().toString());
    QListWidgetItem *item = new QListWidgetItem(deviceLabel);
    item->setData(Qt::UserRole, info.address().toString());
    ui->listWidget->addItem(item);
}

void BluetoothDialog::on_connectPushButton_clicked()
{
    if (bluetoothSocket->state() == QBluetoothSocket::SocketState::ConnectingState ||
        bluetoothSocket->state() == QBluetoothSocket::SocketState::ConnectedState) {
        qDebug() << "Já existe uma conexão em andamento ou já estamos conectados.";
        qDebug() << "Já existe uma conexão em andamento ou já estamos conectados.";
        return;
    }

    QListWidgetItem *selectedItem = ui->listWidget->currentItem();
    if (selectedItem) {
        QString address = selectedItem->data(Qt::UserRole).toString();
        qDebug() << "Tentando conectar ao endereço:" << address;

        // Usando o UUID do perfil Serial Port (SPP)
        QBluetoothUuid serialPortUuid(QStringLiteral("00001101-0000-1000-8000-00805F9B34FB"));
        bluetoothSocket->connectToService(QBluetoothAddress(address), serialPortUuid);
    }
    else {
        qDebug() << "Nenhum dispositivo selecionado para conectar.";
    }
}

void BluetoothDialog::socketConnected()
{
    qDebug() << "Conectado ao dispositivo Bluetooth";

    emit bluetoothConnected(bluetoothSocket);  // Emite o sinal informando que o Bluetooth conectou

    accept();  // Fecha o diálogo ao conectar
}

void BluetoothDialog::socketErrorOccurred(QBluetoothSocket::SocketError error)
{
    qDebug() << "Erro ao conectar: " << bluetoothSocket->errorString();
}










