#ifndef CARCONTROLLER_H
#define CARCONTROLLER_H

#include <QObject>
#include "BluetoothHandler.h"

// CarController class handles car commands and communicates through BluetoothHandler
class CarController : public QObject {
    Q_OBJECT

public:
    explicit CarController(BluetoothHandler *bluetoothHandler, QObject *parent = nullptr);
    void moveForward();
    void moveBack();
    void moveLeft();
    void moveRight();
    void toggleAutoMode(bool enable);

private:
    BluetoothHandler *bluetoothHandler;
};

#endif // CARCONTROLLER_H
