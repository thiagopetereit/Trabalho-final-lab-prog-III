#ifndef BLUETOOTHHANDLER_H
#define BLUETOOTHHANDLER_H

#include <QObject>
#include <QBluetoothSocket>
#include <QBluetoothDeviceDiscoveryAgent>
#include <QBluetoothDeviceInfo>

class BluetoothHandler : public QObject {
    Q_OBJECT

public:
    explicit BluetoothHandler(QObject *parent = nullptr);
    void startDiscovery();
    void connectToDevice(const QString &deviceAddress);
    void sendBluetoothData(const QString &data);
    bool isConnected();  // Método para verificar se está conectado

signals:
    void deviceDiscovered(const QString &deviceName, const QString &deviceAddress);
    void connected();
    void disconnected();
    void errorOccurred(const QString &error);
    void dataReceived(const QString &data);  // Novo sinal para dados recebidos

private slots:
    void deviceDiscoveredHandler(const QBluetoothDeviceInfo &info);
    void socketConnected();
    void socketDisconnected();
    void socketErrorOccurred(QBluetoothSocket::SocketError error);
    void socketReadyRead();  // Novo slot para dados prontos no socket

private:
    QBluetoothSocket *bluetoothSocket;
    QBluetoothDeviceDiscoveryAgent *discoveryAgent;
};

#endif // BLUETOOTHHANDLER_H
