#ifndef BLUETOOTHHANDLER_H
#define BLUETOOTHHANDLER_H

#include <QObject>
#include <QBluetoothSocket>
#include <QBluetoothDeviceDiscoveryAgent>
#include <QBluetoothDeviceInfo>

class BluetoothHandler : public QObject {
    Q_OBJECT

public:
    explicit BluetoothHandler(QObject *parent = nullptr);
    void startDiscovery();
    void connectToDevice(const QString &deviceAddress);
    void sendBluetoothData(const QString &data);

signals:
    void deviceDiscovered(const QString &deviceName, const QString &deviceAddress);
    void connected();
    void disconnected();
    void errorOccurred(const QString &error);

private slots:
    void deviceDiscoveredHandler(const QBluetoothDeviceInfo &info);
    void socketConnected();
    void socketDisconnected();
    void socketErrorOccurred(QBluetoothSocket::SocketError error);

private:
    QBluetoothSocket *bluetoothSocket;
    QBluetoothDeviceDiscoveryAgent *discoveryAgent;
};

#endif // BLUETOOTHHANDLER_H
