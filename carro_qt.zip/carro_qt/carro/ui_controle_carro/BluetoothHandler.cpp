#include "BluetoothHandler.h"
#include <QBluetoothLocalDevice>
#include <QDebug>

// Constructor initializes the discovery agent and the Bluetooth socket
BluetoothHandler::BluetoothHandler(QObject *parent)
    : QObject(parent),
    bluetoothSocket(new QBluetoothSocket(QBluetoothServiceInfo::RfcommProtocol, this)),
    discoveryAgent(new QBluetoothDeviceDiscoveryAgent(this))
{
    // Conectar o sinal readyRead ao slot socketReadyRead
    connect(bluetoothSocket, &QBluetoothSocket::readyRead, this, &BluetoothHandler::socketReadyRead);

    // Outros sinais
    connect(discoveryAgent, &QBluetoothDeviceDiscoveryAgent::deviceDiscovered,
        this, &BluetoothHandler::deviceDiscoveredHandler);
    connect(bluetoothSocket, &QBluetoothSocket::connected,
        this, &BluetoothHandler::socketConnected);
    connect(bluetoothSocket, &QBluetoothSocket::disconnected,
        this, &BluetoothHandler::socketDisconnected);
    connect(bluetoothSocket, QOverload<QBluetoothSocket::SocketError>::of(&QBluetoothSocket::errorOccurred),
        this, &BluetoothHandler::socketErrorOccurred);
}

void BluetoothHandler::socketReadyRead() {
    QString response = QString::fromUtf8(bluetoothSocket->readAll());
    emit dataReceived(response);  // Emite o sinal com os dados recebidos
}

// Starts Bluetooth device discovery
void BluetoothHandler::startDiscovery() {
    discoveryAgent->start();
}

// Connects to a specific device by address
void BluetoothHandler::connectToDevice(const QString &deviceAddress) {
    // Usando o UUID padrão do Serial Port Profile (SPP)
    QBluetoothUuid serialPortUuid(QStringLiteral("00001101-0000-1000-8000-00805F9B34FB"));
    bluetoothSocket->connectToService(QBluetoothAddress(deviceAddress), serialPortUuid);
}

// Sends data via Bluetooth
void BluetoothHandler::sendBluetoothData(const QString &data)
{
    if (bluetoothSocket && bluetoothSocket->isOpen()) {
        qDebug() << "Enviando dados via Bluetooth:" << data;
        bluetoothSocket->write(data.toUtf8());  // Converte para QByteArray
    } else {
        qDebug() << "Erro: Socket Bluetooth não está aberto!";
    }
}


bool BluetoothHandler::isConnected() {
    return bluetoothSocket && bluetoothSocket->state() == QBluetoothSocket::SocketState::ConnectedState;
}

// Slot to handle discovered devices
void BluetoothHandler::deviceDiscoveredHandler(const QBluetoothDeviceInfo &info) {
    emit deviceDiscovered(info.name(), info.address().toString());
}

// Slot for when the socket is connected
void BluetoothHandler::socketConnected() {
    emit connected();
}

// Slot for when the socket is disconnected
void BluetoothHandler::socketDisconnected() {
    emit disconnected();
}

// Slot for handling socket errors
void BluetoothHandler::socketErrorOccurred(QBluetoothSocket::SocketError error) {
    emit errorOccurred(bluetoothSocket->errorString());
}
