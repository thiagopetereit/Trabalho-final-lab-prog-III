#include "BluetoothHandler.h"
#include <QBluetoothLocalDevice>
#include <QDebug>

// Constructor initializes the discovery agent and the Bluetooth socket
BluetoothHandler::BluetoothHandler(QObject *parent) : QObject(parent) {
    discoveryAgent = new QBluetoothDeviceDiscoveryAgent(this);
    bluetoothSocket = new QBluetoothSocket(QBluetoothServiceInfo::RfcommProtocol, this);

    connect(discoveryAgent, &QBluetoothDeviceDiscoveryAgent::deviceDiscovered,
            this, &BluetoothHandler::deviceDiscoveredHandler);

    connect(bluetoothSocket, &QBluetoothSocket::connected,
            this, &BluetoothHandler::socketConnected);
    connect(bluetoothSocket, &QBluetoothSocket::disconnected,
            this, &BluetoothHandler::socketDisconnected);
    connect(bluetoothSocket, QOverload<QBluetoothSocket::SocketError>::of(&QBluetoothSocket::errorOccurred),
            this, &BluetoothHandler::socketErrorOccurred);
}

// Starts Bluetooth device discovery
void BluetoothHandler::startDiscovery() {
    discoveryAgent->start();
}

// Connects to a specific device by address
void BluetoothHandler::connectToDevice(const QString &deviceAddress) {
    // Usando o UUID padrão do Serial Port Profile (SPP)
    QBluetoothUuid serialPortUuid(QStringLiteral("00001101-0000-1000-8000-00805F9B34FB"));
    bluetoothSocket->connectToService(QBluetoothAddress(deviceAddress), serialPortUuid);
}

// Sends data via Bluetooth
void BluetoothHandler::sendBluetoothData(const QString &data) {
    if (bluetoothSocket && bluetoothSocket->isOpen()) {
        bluetoothSocket->write(data.toUtf8());
    }
}

// Slot to handle discovered devices
void BluetoothHandler::deviceDiscoveredHandler(const QBluetoothDeviceInfo &info) {
    emit deviceDiscovered(info.name(), info.address().toString());
}

// Slot for when the socket is connected
void BluetoothHandler::socketConnected() {
    emit connected();
}

// Slot for when the socket is disconnected
void BluetoothHandler::socketDisconnected() {
    emit disconnected();
}

// Slot for handling socket errors
void BluetoothHandler::socketErrorOccurred(QBluetoothSocket::SocketError error) {
    emit errorOccurred(bluetoothSocket->errorString());
}
