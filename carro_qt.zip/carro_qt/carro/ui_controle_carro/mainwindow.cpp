#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "bluetoothdialog.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Instantiate BluetoothHandler and CarController
    bluetoothHandler = new BluetoothHandler(this);
    carController = new CarController(bluetoothHandler, this);

    // Connect BluetoothHandler signals to UI elements
    connect(bluetoothHandler, &BluetoothHandler::connected, this, [this]() {
        ui->statusLabel->setText("Conectado ao Bluetooth");
    });
    connect(bluetoothHandler, &BluetoothHandler::disconnected, this, [this]() {
        ui->statusLabel->setText("Desconectado");
    });
    connect(bluetoothHandler, &BluetoothHandler::errorOccurred, this, [this](const QString &error) {
        ui->statusLabel->setText("Erro: " + error);
    });

    bluetoothHandler->startDiscovery();
}

MainWindow::~MainWindow()
{
    delete ui;
    delete bluetoothHandler;
    delete carController;
}

void MainWindow::on_actionBluetooth_triggered() {
    BluetoothDialog *btDialog = new BluetoothDialog(this);
    btDialog->setModal(true);
    btDialog->show();
}

void MainWindow::on_distHorizontalSlider_sliderMoved(int position)
{
    int distance = 5 + position * 5; // Convert position to distance
    ui->distLabel->setText(QString::number(distance) + " cm");
    bluetoothHandler->sendBluetoothData(QString("DIST:%1\\n").arg(distance));
}

void MainWindow::on_forwardButton_clicked()
{
    carController->moveForward();
}

void MainWindow::on_backButton_clicked()
{
    carController->moveBack();
}

void MainWindow::on_leftButton_clicked()
{
    carController->moveLeft();
}

void MainWindow::on_rightButton_clicked()
{
    carController->moveRight();
}

void MainWindow::on_autoButton_clicked()
{
    static bool isAutoEnabled = false;
    isAutoEnabled = !isAutoEnabled;
    ui->autoPushButton->setText(isAutoEnabled ? "Desativar Estacionamento Automático" : "Ativar Estacionamento Automático");
    carController->toggleAutoMode(isAutoEnabled);
}
