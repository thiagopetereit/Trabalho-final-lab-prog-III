#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "BluetoothHandler.h"
#include "bluetoothdialog.h"
#include "carcontroller.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , distanceUpdateTimer(new QTimer(this)) // Inicializa o timer
{
    ui->setupUi(this);

    // Inicializa BluetoothHandler e CarController
    bluetoothHandler = new BluetoothHandler(this);
    carController = new CarController(bluetoothHandler, this);

    // Conecta o botão para BluetoothDialog
    connect(bluetoothHandler, &BluetoothHandler::connected, this, [this]() {
        ui->statusLabel->setText("Conectado ao Bluetooth");
    });
    connect(bluetoothHandler, &BluetoothHandler::disconnected, this, [this]() {
        ui->statusLabel->setText("Desconectado");
    });
    connect(bluetoothHandler, &BluetoothHandler::errorOccurred, this, [this](const QString &error) {
        ui->statusLabel->setText("Erro: " + error);
    });

    // Configura o timer para atualização da distância
    connect(distanceUpdateTimer, &QTimer::timeout, this, &MainWindow::updateDistance);
    distanceUpdateTimer->start(1000); // Atualiza a cada 1000 ms (1 segundo)

    // Conecte o sinal do BluetoothDialog ao slot para definir o socket no BluetoothHandler
    connect(bluetoothDialog, &BluetoothDialog::bluetoothConnected, bluetoothHandler, &BluetoothHandler::setSocket);

    // Conecte o sinal do BluetoothHandler ao slot para processar os dados recebidos
    connect(bluetoothHandler, &BluetoothHandler::dataReceived, this, &MainWindow::handleBluetoothResponse);

    bluetoothHandler->startDiscovery();
}

MainWindow::~MainWindow()
{
    delete ui;
    delete bluetoothHandler;
    delete carController;
}

void MainWindow::on_actionBluetooth_triggered()
{
    qDebug() << "Tentando abrir o BluetoothDialog";
    BluetoothDialog bluetoothDialog(this);
    bluetoothDialog.exec(); // Usa exec() para abrir como modal, ou show() para não-modal
}

void MainWindow::on_distHorizontalSlider_sliderMoved(int position)
{
    // Código que lida com o movimento do slider de distância
    qDebug() << "Slider movido para posição: " << position;
    carController->setDistance(position);
}

void MainWindow::updateDistance()
{
    if (bluetoothHandler && bluetoothHandler->isConnected()) {
        // Envia comando para solicitar a leitura da distância do sensor
        bluetoothHandler->sendBluetoothData("READ:DISTANCE\n");
    }
}

// Receber resposta do Bluetooth e atualizar a distância na interface
void MainWindow::handleBluetoothResponse(const QString &response)
{
    if (response.startsWith("DIST:")) {
        int distance = response.section(':', 1).toInt();
        ui->distLabel->setText(QString::number(distance) + " cm");
    }
}

void MainWindow::on_autoButton_clicked() {
    static bool isAutoEnabled = false;
    isAutoEnabled = !isAutoEnabled;
    ui->autoButton->setText(isAutoEnabled ? "Desativar Estacionamento Automático" : "Ativar Estacionamento Automático");
    carController->toggleAutoMode(isAutoEnabled);
}

void MainWindow::on_forwardButton_clicked()
{
    // Lógica para mover o carro para frente
    qDebug() << "Botão de avançar clicado";
    carController->moveForward();
}

void MainWindow::on_backButton_clicked()
{
    // Lógica para mover o carro para trás
    qDebug() << "Botão de retroceder clicado";
    carController->moveBack();
}

void MainWindow::on_leftButton_clicked()
{
    // Lógica para mover o carro para a esquerda
    qDebug() << "Botão para mover à esquerda clicado";
    carController->moveLeft();
}

void MainWindow::on_rightButton_clicked()
{
    // Lógica para mover o carro para a direita
    qDebug() << "Botão para mover à direita clicado";
    carController->moveRight();
}
