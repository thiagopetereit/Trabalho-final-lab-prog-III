#include "carcontroller.h"
#include <QDebug>

// Constructor initializes the reference to BluetoothHandler
CarController::CarController(BluetoothHandler *bluetoothHandler, QObject *parent)
    : QObject(parent),
    bluetoothHandler(bluetoothHandler),
    currentDistance(0) // Inicializa a distância atual
{
}

void CarController::setDistance(int distance)
{
    currentDistance = distance;  // Atualiza a distância armazenada
    qDebug() << "Distância configurada para:" << distance << "cm";

    // Enviar a distância ao Arduino, se necessário
    if (bluetoothHandler && bluetoothHandler->isConnected()) {
        QString command = QString("SET:DISTANCE:%1\n").arg(distance);
        bluetoothHandler->sendBluetoothData(command);
    }
}

// Sends a command to move forward
void CarController::moveForward() {
    if (bluetoothHandler && bluetoothHandler->isConnected()) {
        QString command = "CMD:FORWARD\n";
        qDebug() << "Enviando comando para mover para frente:" << command;
        bluetoothHandler->sendBluetoothData(command);
    } else {
        qDebug() << "Erro: Bluetooth não está conectado. Não foi possível mover para frente.";
    }
}

// Sends a command to move backward
void CarController::moveBack() {
    bluetoothHandler->sendBluetoothData("CMD:BACK\n");
}

// Sends a command to turn left
void CarController::moveLeft() {
    bluetoothHandler->sendBluetoothData("CMD:LEFT\n");
}

// Sends a command to turn right
void CarController::moveRight() {
    bluetoothHandler->sendBluetoothData("CMD:RIGHT\n");
}

// Toggles automatic parking mode
void CarController::toggleAutoMode(bool enable) {
    bluetoothHandler->sendBluetoothData(enable ? "AUTO:ON\n" : "AUTO:OFF\n");
}
