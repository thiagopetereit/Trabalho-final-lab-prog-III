#include "CarController.h"

// Constructor initializes the reference to BluetoothHandler
CarController::CarController(BluetoothHandler *bluetoothHandler, QObject *parent)
    : QObject(parent), bluetoothHandler(bluetoothHandler) {}

// Sends a command to move forward
void CarController::moveForward() {
    bluetoothHandler->sendBluetoothData("CMD:FORWARD\\n");
}

// Sends a command to move backward
void CarController::moveBack() {
    bluetoothHandler->sendBluetoothData("CMD:BACK\\n");
}

// Sends a command to turn left
void CarController::moveLeft() {
    bluetoothHandler->sendBluetoothData("CMD:LEFT\\n");
}

// Sends a command to turn right
void CarController::moveRight() {
    bluetoothHandler->sendBluetoothData("CMD:RIGHT\\n");
}

// Toggles automatic parking mode
void CarController::toggleAutoMode(bool enable) {
    bluetoothHandler->sendBluetoothData(enable ? "AUTO:ON\\n" : "AUTO:OFF\\n");
}
